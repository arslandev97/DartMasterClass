void main(){

  // Run First Dart Program
  print("Alhamdulillah Run First Dart Program!");

  
  // Print Statemen USing Single Quotes 
  print('Welcome to Dart Flutter Course');


  // Understand Dart Basic Syntax
  // What is Syntax?
  
  // Example : print();
  print("welcome");

  // Error : Bug --> Debug 
  // 1. Syntax Error

  // print("Hello World!") // Syntax Error
  // print("Hello World!");

  
  // 2. Logical Error
  // Write a program in which Add two Numbers and print their sum 
  // print('Sum = ${10 - 10}');


  // 3. Run Time Error
  // A runtime error is an error that occurs when a program you're using or writing crashes or produces a wrong output.
  // print(10/0);


  // Semicolon in Dart
  // The semicolon is used to terminate the statement that means,it indicates the statement is ended here.

  print("Hellow World!");
  var firstName = "Arslan";
  print(firstName);

  // DartPad.dev
  // Browser Base IDE : Integrated Development Envirement
  // DartPad is an open source tool that lets you play with the Dart language in any modern browser.


  
}
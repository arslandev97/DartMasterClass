void main() {
  
  // Data Types
  // data types is a classification or categorization of data. 

  // var number1= 1234564; // 4 byte
  // var number2= 456;

  // var firstName = "Arslan";
  // var lastName = "Yousaf";

  
  // 1. Numbers ---> integers ---> Floating Point Numbers 
  // int --> Integers

  // int studentAge = 18.5; // Generate an error
  // int studentAge = 18;
  // print(studentAge);
  // print(studentAge.runtimeType);
  // print('Student Age is ${studentAge}');

  
  // double ---> Floating Point Values 
  // double salary = 1000.80;
  // print(salary);
  // print(salary.runtimeType);
  // print("Employee Salary is $salary");
  // print("Employee Salary is ${salary}");

  // double productPrice = 100;
  // print(productPrice);


  // 2. String ---> A string is a sequence of characters. 
  //  you can create a string by enclosing a sequence of characters in single or double quotes.

  // String personName = "Arslan";
  // print("My Name is $personName");
  // print("Welcome Mr.$personName & datatype is ${personName.runtimeType}");

  // var EmployeeName = "Ali Raza";
  // print(EmployeeName);
  // print(EmployeeName.runtimeType);


  // 3. bool ---> Booleans 
  // A boolean is a data type that has two possible values: true and false.

  // int marks = 61;
  // bool result = marks > 33;
  // bool result = 33 >= 33;
  // bool hello = true;
  // print(hello);
  // print(result);
  // print(result.runtimeType);



}